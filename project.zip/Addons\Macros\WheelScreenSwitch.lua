Macro {
  area="Editor Shell Viewer"; key="ShiftMsWheelUp"; description="Use Shift-MsWheel to switch between screens"; action = function()
Keys('F12 Up Enter')
  end;
}

Macro {
  area="Editor Shell Viewer"; key="ShiftMsWheelDown"; description="Use Shift-MsWheel to switch between screens"; action = function()
Keys('F12 Down Enter')
  end;
}
