Macro {
  area="Shell"; key="Apps"; description="Apps - Open Change drive in current panel"; action = function()
Keys('F9 Enter Up Enter')
  end;
}

