Macro {
  area="Shell"; key="BS"; flags="EmptyCommandLine"; description="Use BS to go to upper folder"; action = function()
Keys('CtrlPgUp')
  end;
}

