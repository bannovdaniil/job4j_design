Macro {
  area="Shell"; key="MsM2Click"; description="Tilt mouse wheel Left"; action = function()
Keys('CtrlPgUp')
  end;
}

Macro {
  area="Shell"; key="MsM3Click"; description="Tilt mouse wheel Right"; action = function()
Keys('CtrlPgDn')
  end;
}

