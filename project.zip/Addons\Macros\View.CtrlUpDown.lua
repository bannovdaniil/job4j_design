Macro {
  area="Viewer"; key="CtrlDown"; description="Scroll Down text in internal viewer"; action = function()
Keys('Down')
  end;
}

Macro {
  area="Viewer"; key="CtrlUp"; description="Scroll Up text in internal viewer"; action = function()
Keys('Up')
  end;
}

